clear &&
cp __init__.py ~/.config/blender/2.91/scripts/addons/HKX2Tools/
